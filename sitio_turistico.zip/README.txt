# Sitio turístico - Instrucciones rápidas

## Edita tu contenido
- Reemplaza `fondo.jpg` por tu imagen de fondo.
- Cambia `foto1.jpg`, `foto2.jpg`, `foto3.jpg`, `foto4.jpg` por tus fotos.
- Sustituye `TU_VIDEO` en el iframe de YouTube por el ID de tu video (lo que va después de `watch?v=`).
- Actualiza los enlaces de Facebook e Instagram con tus páginas reales.

## Publicar con GitHub Pages (gratis)
1) Crea un repositorio en GitHub, por ejemplo `turismo`.
2) Sube los archivos de esta carpeta (incluyendo `index.html`).
3) En **Settings → Pages**, selecciona **Deploy from a branch** y la rama `main` con la carpeta `/ (root)`.
4) Tu link directo será: `https://TU_USUARIO.github.io/turismo/`

## Publicar con Netlify (muy fácil)
1) Entra a https://app.netlify.com/drop
2) Arrastra la carpeta completa.
3) Te dará un link directo del estilo `https://nombre-aleatorio.netlify.app/`

## Publicar con Vercel
1) Crea una cuenta en https://vercel.com/ y crea un nuevo proyecto.
2) Importa tu repositorio o sube la carpeta.
3) Obtendrás un link directo del estilo `https://turismo.vercel.app/`
